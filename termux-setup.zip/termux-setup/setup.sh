#!/bin/bash
# Termux Auto Setup Script by androidtipss-v19

echo "📦 Updating & Upgrading packages..."
pkg update -y && pkg upgrade -y

echo "📥 Installing essential packages..."
pkg install -y git wget curl nano vim python php nodejs clang zip unzip openssh tsu net-tools

echo "🗂️ Setting up storage access..."
termux-setup-storage

echo "📁 Creating directory in shared storage..."
cd /sdcard && mkdir -p TermuxFiles

echo "✅ Version check:"
python --version
php --version
node --version
git --version

echo -e "\n🎉 Done! Termux is ready to use."
