# Termux Auto Setup - androidtipss-v19

**Automated Termux setup on Android**

## Usage

```bash
git clone https://github.com/androidtipss-v19/termux-setup.git
cd termux-setup
bash setup.sh
```

## Installs:
- git, wget, curl
- nano, vim
- python, php, nodejs
- clang, zip, unzip
- openssh, tsu, net-tools

Creates `/sdcard/TermuxFiles` and sets storage permissions.
